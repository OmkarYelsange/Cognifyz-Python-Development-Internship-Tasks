#String Reversal

def reverse_string(input_str):
    # Reverse the string using slicing
    return input_str[::-1]

# Example usage
user_input = input("Enter a string to reverse: ")
print("Reversed string:", reverse_string(user_input))
