#Palindrome Checker

def is_palindrome(word):
    # Remove case sensitivity and spaces for robust check
    cleaned = word.replace(" ", "").lower()
    return cleaned == cleaned[::-1]

# Example usage
text = input("Enter a word or phrase: ")
if is_palindrome(text):
    print("It's a palindrome!")
else:
    print("Not a palindrome.")
