#Guessing Game

import random

def guessing_game():
    number_to_guess = random.randint(1, 100)
    attempts = 0

    print("Guess a number between 1 and 100:")

    while True:
        try:
            guess = int(input("Your guess: "))
            attempts += 1

            if guess < number_to_guess:
                print("Too low!")
            elif guess > number_to_guess:
                print("Too high!")
            else:
                print(f"Correct! You guessed it in {attempts} tries.")
                break
        except ValueError:
            print("Please enter a valid number.")

# Start the game
guessing_game()
