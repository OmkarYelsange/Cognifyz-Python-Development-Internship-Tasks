#Number Guesser

import random

def number_guesser():
    try:
        low = int(input("Enter the lower bound: "))
        high = int(input("Enter the upper bound: "))
        number = random.randint(low, high)

        while True:
            guess = int(input(f"Guess the number between {low} and {high}: "))
            if guess < number:
                print("Too low!")
            elif guess > number:
                print("Too high!")
            else:
                print("Congratulations! You guessed the number.")
                break
    except ValueError:
        print("Please enter valid numbers.")

number_guesser()
