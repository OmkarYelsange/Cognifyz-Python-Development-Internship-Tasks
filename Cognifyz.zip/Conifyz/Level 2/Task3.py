#Password Strength Checker

import re

def check_password_strength(password):
    length = len(password) >= 8
    upper = re.search(r'[A-Z]', password)
    lower = re.search(r'[a-z]', password)
    digit = re.search(r'[0-9]', password)
    special = re.search(r'[\W_]', password)

    if all([length, upper, lower, digit, special]):
        return "Strong password."
    else:
        return "Weak password. Use a mix of upper, lower, digits, and special characters."

# Input from user
password = input("Enter your password: ")
print(check_password_strength(password))
