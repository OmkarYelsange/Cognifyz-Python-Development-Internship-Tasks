#Fibonacci Sequence

def fibonacci(n):
    a, b = 0, 1
    for _ in range(n):
        print(a, end=' ')
        a, b = b, a + b

# Example usage
try:
    terms = int(input("Enter the number of terms: "))
    if terms <= 0:
        print("Please enter a positive integer.")
    else:
        print("Fibonacci sequence:")
        fibonacci(terms)
except ValueError:
    print("Invalid input! Please enter a valid integer.")
