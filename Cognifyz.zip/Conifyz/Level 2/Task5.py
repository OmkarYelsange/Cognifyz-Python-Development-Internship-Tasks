#File Manipulation

from collections import Counter

def count_words(filename):
    try:
        with open(filename, 'r') as file:
            text = file.read().lower()
            words = re.findall(r'\b\w+\b', text)
            word_count = Counter(words)

            for word in sorted(word_count):
                print(f"{word}: {word_count[word]}")
    except FileNotFoundError:
        print("File not found.")

# Example usage
filename = input("Enter the filename (with extension): ")
count_words(filename)
