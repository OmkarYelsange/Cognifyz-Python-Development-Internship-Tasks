#Build a Web Scraper

import requests
from bs4 import BeautifulSoup

def scrape_titles(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    # Extract all <h1> titles from the page
    titles = soup.find_all('h1')
    for title in titles:
        print("Title:", title.text.strip())

# Example usage
url = input("Enter the website URL to scrape: ")
scrape_titles(url)
