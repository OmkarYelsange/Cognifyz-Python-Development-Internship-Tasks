#Data Visualization Tool

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

def visualize_data(file_path):
    data = pd.read_csv(file_path)
    print("Data columns:", data.columns.tolist())
    x = input("Enter column for x-axis: ")
    y = input("Enter column for y-axis: ")

    sns.scatterplot(data=data, x=x, y=y)
    plt.title("Data Visualization")
    plt.show()

# Example usage
file_path = input("Enter path to CSV file: ")
visualize_data(file_path)
