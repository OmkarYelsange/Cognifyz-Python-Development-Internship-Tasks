#Automate a Task

import os

def rename_files(folder_path):
    for i, filename in enumerate(os.listdir(folder_path), 1):
        extension = os.path.splitext(filename)[1]
        new_name = f"file_{i}{extension}"
        old_path = os.path.join(folder_path, filename)
        new_path = os.path.join(folder_path, new_name)
        os.rename(old_path, new_path)
        print(f"Renamed {filename} -> {new_name}")

# Example usage
folder_path = input("Enter folder path to rename files: ")
rename_files(folder_path)
